using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using SchedulerService.Business.Commands;

namespace SchedulerService.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class JobsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public JobsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        public async Task<IActionResult> ScheduleJob([FromBody] ScheduleJobCommand command)
        {
            var result = await _mediator.Send(command);
            if (result == "Job scheduled.")
            {
                return Ok(result);
            }
            else
            {
                return BadRequest(result);
            }
        }
    }
}
