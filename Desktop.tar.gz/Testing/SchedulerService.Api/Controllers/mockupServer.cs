using Microsoft.AspNetCore.Mvc;

namespace SchedulerService.Api.Controllers
{
    [ApiController]
    [Route("[Controller]")]
    public class MockupServerController : ControllerBase
    {
        [HttpPost]
        public IActionResult ReceiveData([FromBody] object data)
        {
            var requestId = Guid.NewGuid().ToString();
            return Ok(new { request_Id = requestId });
        }
    }
}