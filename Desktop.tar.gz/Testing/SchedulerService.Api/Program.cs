using SchedulerService.DependencyInjection.Services;
using SchedulerService.DependencyInjection.Configurations;
using Serilog;


LoggingConfiguration.ConfigureLogger();
var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog();
builder.Services.AddProjectServices(builder.Configuration);

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();