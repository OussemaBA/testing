using Serilog;
using Serilog.Filters;

namespace SchedulerService.DependencyInjection.Configurations;
public abstract class LoggingConfiguration
{
        public static void ConfigureLogger()
        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Logger(lc => lc
                    .Filter.ByIncludingOnly(Matching.FromSource("DummyJob"))
                    .WriteTo.File("logs/DummyJob.log", rollingInterval: RollingInterval.Day))
                .WriteTo.Console()
                .CreateLogger();
        }
}