﻿using Microsoft.Extensions.DependencyInjection;
using Quartz;
using Quartz.Impl;
using Quartz.Simpl;
using Quartz.Spi;
using SchedulerService.Business.Commands;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using SchedulerService.DAL;

namespace SchedulerService.DependencyInjection.Services
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddProjectServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddControllers();
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen();
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(ScheduleJobCommand).Assembly));
            services.AddSingleton<IJobFactory, MicrosoftDependencyInjectionJobFactory>();
            services.AddSingleton<ISchedulerFactory, StdSchedulerFactory>();
            services.AddSingleton<IScheduler>(provider =>
            {
                var schedulerFactory = provider.GetRequiredService<ISchedulerFactory>();
                var jobFactory = provider.GetRequiredService<IJobFactory>();
                var scheduler = schedulerFactory.GetScheduler().Result;
                scheduler.JobFactory = jobFactory;
                return scheduler;
            });
            
            services.AddQuartzHostedService(q => q.WaitForJobsToComplete = true);
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("SchedulerServiceDB")));
            return services;
        }
    }
}