using SchedulerService.Business.Commands;
using SchedulerService.Business.Jobs;
namespace SchedulerService.Business.Handlers;

using MediatR;
using Quartz;
using System.Threading;
using System.Threading.Tasks;

public class ScheduleJobCommandHandler : IRequestHandler<ScheduleJobCommand, string>
{
    private readonly IScheduler _scheduler;

    public ScheduleJobCommandHandler(IScheduler scheduler)
    {
        _scheduler = scheduler;
    }

    public async Task<string> Handle(ScheduleJobCommand request, CancellationToken cancellationToken)
    {
        var jobKey = new JobKey("DummyJob");
        if (!await _scheduler.CheckExists(jobKey, cancellationToken))
        {
            var jobDataMap = new JobDataMap();
            jobDataMap.Put("scriptUrl", request.ScriptUrl);
            jobDataMap.Put("parameters", request.Parameters);

            var job = JobBuilder.Create<DummyJob>().SetJobData(jobDataMap).WithIdentity(jobKey).Build();
            var trigger = TriggerBuilder.Create()
                .WithIdentity("DummyJobTrigger")
                .StartNow()
                .WithSimpleSchedule(x => x.WithIntervalInSeconds(10).RepeatForever())
                .Build();
            await _scheduler.ScheduleJob(job, trigger,cancellationToken);
            return "Job scheduled.";
        }
        else
        {
            return "Job already exists.";
        }
    }
}
