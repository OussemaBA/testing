using System.Net.Http.Json;
using Microsoft.Extensions.Logging;
using Quartz;
namespace SchedulerService.Business.Jobs
{
    public class DummyJob : IJob
    {
         private readonly ILogger<DummyJob> _logger;
         
         public DummyJob(ILogger<DummyJob> logger)
         {
             _logger = logger;
         }
        public async Task Execute(IJobExecutionContext context)
        {
            var dataMap = context.MergedJobDataMap;
            var scriptUrl = dataMap.GetString("scriptUrl");
            var parameters = dataMap.GetString("parameters");
            
            var client = new HttpClient();
            var response = await client.PostAsJsonAsync("http://localhost:5161/mockupServer", new { param = "[....parameters...]" });
            var responseData = await response.Content.ReadFromJsonAsync<Dictionary<string, string>>();

            if (responseData != null)
                _logger.LogInformation("Received response: {RequestId}", responseData["request_Id"]);
            await Task.CompletedTask;
        }
    }
}