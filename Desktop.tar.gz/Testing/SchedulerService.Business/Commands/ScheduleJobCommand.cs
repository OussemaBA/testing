using MediatR;


namespace SchedulerService.Business.Commands;

public class ScheduleJobCommand : IRequest<string>
{
    public string ScriptUrl { get; set; }
    public string Parameters { get; set; }
}