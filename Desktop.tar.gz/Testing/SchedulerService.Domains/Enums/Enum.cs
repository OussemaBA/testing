namespace SchedulerService.Domains.Enums;

 public enum JobStatus
    {
        Pending,
        Running,
        Completed,
        Failed,
    }