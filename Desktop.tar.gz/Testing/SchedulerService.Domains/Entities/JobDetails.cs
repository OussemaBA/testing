using SchedulerService.Domains.Enums;

namespace SchedulerService.Domains.Entities;

public class JobDetails
{
    public int Id { get; set; }
    public string CronExpression { get; set; } 
    public string Endpoint { get; set; } 
    public DateTime LastExecuted { get; set; } 
    public string CallParameters { get; set; } 
    public DateTime LaunchedAt { get; set; } 
    public string RequestId { get; set; } 
    public JobStatus Status { get; set; } 
}