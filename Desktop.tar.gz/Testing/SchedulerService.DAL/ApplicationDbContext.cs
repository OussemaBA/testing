using Microsoft.EntityFrameworkCore;
using SchedulerService.Domains.Entities;

namespace SchedulerService.DAL
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }
        public DbSet<JobDetails> Posts { get; set; }
    }
}